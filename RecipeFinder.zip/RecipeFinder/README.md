Berikut adalah tampilan hasil aplikasi saat berjalan:

![RecipesFinder](/images/result1)
![RecipesFinder](/images/result2)
![RecipesFinder](/images/result3)

## Technologies Used

- JavaScript / HTML / CSS
- ES6 Standart Sintaks
- Custom Element Includes
- Webpack Module Bundler (Production)
- Webpack Environment Development (Development)
- Api used with AJAX Concepts

Created by Riandra Alkautsar (riandra.alkautsar@gmail.com)
